insert into bindings
( ip,
  type) 
VALUES 
( :ip:,
  :type:);

  $( document ).ready(function() {


                $('.fade-in-left').bind('inview', function (event, visible) {
                  if (visible == true) {
                    $(this).addClass('animated fadeInLeft');
                  } else {
                    $(this).removeClass('animated fadeInLeft');
                  }
                });

                $('.fade-in-right').bind('inview', function (event, visible) {
                  if (visible == true) {
                    $(this).addClass('animated fadeInRight');
                  } else {
                    $(this).removeClass('animated fadeInRight');
                  }
                });

                $('.fade-in-bouncein').bind('inview', function (event, visible) {
                  if (visible == true) {
                    $(this).addClass('animated bounceIn');
                  } else {
                    $(this).removeClass('animated bounceIn');
                  }
                });

                $('.fade-in-rubber').bind('inview', function (event, visible) {
                  if (visible == true) {
                    $(this).addClass('animated rubberBand');
                  } else {
                    $(this).removeClass('animated rubberBand');
                  }
                });

                $('.fade-in-bounce').bind('inview', function (event, visible) {
                  if (visible == true) {
                    $(this).addClass('animated bounceIn');
                  } else {
                    $(this).removeClass('animated bounceIn');
                  }
                });

                $('.fade-in-pulse').bind('inview', function (event, visible) {
                  if (visible == true) {
                    $(this).addClass('animated pulse');
                  } else {
                    $(this).removeClass('animated pulse');
                  }
                });

                $('.fade-in-up').bind('inview', function (event, visible) {
                  if (visible == true) {
                    $(this).addClass('animated fadeInUp');
                  } else {
                    $(this).removeClass('animated fadeInUp');
                  }
                });

                $('.fade-in-down').bind('inview', function (event, visible) {
                  if (visible == true) {
                    $(this).addClass('animated fadeInDown');
                  } else {
                    $(this).removeClass('animated fadeInDown');
                  }
                });
                $('.fade-in-filpiny').bind('inview', function (event, visible) {
                  if (visible == true) {
                    $(this).addClass('animated flipInY');
                  } else {
                    $(this).removeClass('animated flipInY');
                  }
                });
                $('.fade-in-filpinx').bind('inview', function (event, visible) {
                  if (visible == true) {
                    $(this).addClass('animated flipInX');
                  } else {
                    $(this).removeClass('animated flipInX');
                  }
                });



            

});